START_MSG = """📲 Shadow Sender BOT™️ 
The #1 Auto Sender BOT ⚡️
➖➖➖➖➖➖➖

👋 Welcome to ShadowBOT,
Our service has all the best & basic features other bots have, and many UNIQUE features never seen before. 
For example -  change the ad direct from bot, set intervals as your choice, do multiple user logins and much more.

☑️ This service is provided by @KrishnnaXD.

💬 If you have a license already, direct proceed using it by doing buyer login with your purchased key. 
If you don’t, 💳 Purchase from @KrishnnaXD.

⭐ updates channel : @ShadowBotUpdate ⭐
⭐ chat-room : @ShadowBotChats ⭐"""


PRICE_LIST = """⭐ Subscription Price List: ⭐\n\n1 Week : ₹130 or $1.5 🚀\n2 Week : ₹250 or $3 🚀 \n1 Month : ₹400 or $5 🚀 \n\n 🚨 NOTE 🚨\n keep in mind that multiple user login feature will only be available on 1 Month plan. 🥢'\n\n🌟 Contact @KrishnnaXD to buy subscription.. 🌟"""