from pyrogram import idle

from . import forwardbot, LOGGER




async def main():
    try:
        LOGGER.info("Starting bot...")
        await forwardbot.start()
    except Exception as e:
        LOGGER.error(e)
    else:
        LOGGER.info("Started..")
        await idle()
        await forwardbot.stop()


forwardbot.run(main())