import loguru

from pyrogram import Client
import pyroaddon
import logging

API_ID = 8526499
API_HASH = "e760875a258346ca77329636217dd492"
LOGGER = loguru.logger
SUPPORT_CHAT = "@OldLostFriends"
BOT_NAME = "Shadow"
SUPPORT_CHANNEL = "I_14344"
SUDO = [2142595466, 1476937429]
TOKEN = "6424967891:AAEqQnRIel1vLvala7OyrjGAE8m6qxCXURM"
forwardbot = Client(
    "forwardbot",
    api_hash=API_HASH,
    api_id=API_ID,
    bot_token=TOKEN,
    plugins={"root":"Forward.modules"}
)