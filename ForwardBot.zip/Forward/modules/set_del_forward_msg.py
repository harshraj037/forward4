from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup

from ..utils.verify_user import is_premium
from .database.main_db import User, UserDatabase


@Client.on_message(filters.regex("Set forward message"))
@is_premium
async def set_forward_msg(bot, m: Message):
    user_id = m.from_user.id
    text = await m.chat.ask("Send me message: ")
    UserDatabase().update_forward_message(user_id, text.text)
    await m.reply("Change successful.")
     


@Client.on_message(filters.regex("Current forward message"))
@is_premium
async def current_forward_msg(bot, m: Message):
    user_id = m.from_user.id
    text = UserDatabase().get_user(user_id).forward_message
    await m.reply(text)


@Client.on_message(filters.regex("Current Interval"))
@is_premium
async def current_interval_time(bot, m: Message):
     
    user_id = m.from_user.id
    itime = UserDatabase().get_user(user_id).interval
    if itime == 30:
        hours = 0
        minutes = 30
    elif itime == 1:
        hours = 1
        minutes = 0
    elif itime == 130:
        hours = 1
        minutes = 30
    elif itime == 2:
        hours = 2
        minutes = 0
    elif itime == 230:
        hours = 2
        minutes = 30
    elif itime == 6:
        hours = 6
        minutes = 0
    elif itime == 630:
        hours = 6
        minutes = 30
    await m.reply(f"Current interval is {hours} hours {minutes} minutes")
     

@Client.on_message(filters.regex("Set Forward interval"))
@is_premium
async def set_interval(bot, m: Message):
     
    user_id = m.from_user.id
    btns = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("30 minutes", callback_data="setinterval_30"),
            ],
            [
                InlineKeyboardButton("1 hour", callback_data="setinterval_1"),
                InlineKeyboardButton("1 hours 30 minutes", callback_data="setinterval_130"),
            ],
            [
                InlineKeyboardButton("2 hours", callback_data="setinterval_2"),
                InlineKeyboardButton("2 hours 30 minutes", callback_data="setinterval_230"),
            ],
            [
                InlineKeyboardButton("6 hours", callback_data="setinterval_6"),
                InlineKeyboardButton("6 hours 30 minutes", callback_data="setinterval_630"),
            ],
        ]
    )
    
    await m.reply("Choose Interval: ", reply_markup=btns)


@Client.on_callback_query(filters.regex("^setinterval_"))
@is_premium
async def setinter(bot, q):
    itime = int(q.data.split("_")[1])
    user_id = q.from_user.id
    if itime == 30:
        hours = 0
        minutes = 30
    elif itime == 1:
        hours = 1
        minutes = 0
    elif itime == 130:
        hours = 1
        minutes = 30
    elif itime == 2:
        hours = 2
        minutes = 0
    elif itime == 230:
        hours = 2
        minutes = 30
    elif itime == 6:
        hours = 6
        minutes = 0
    elif itime == 630:
        hours = 6
        minutes = 30
    UserDatabase().update_interval(user_id, itime)
    await q.answer(f"Interval time changed to {hours} hours {minutes} minutes", show_alert=1)
    await q.message.delete()