import asyncio


from datetime import datetime
from datetime import date

from pyrogram import Client, filters
from pyrogram.types import Message, ReplyKeyboardRemove

from .database.main_db import User, LicenseKey, UserDatabase


@Client.on_message(filters.command("claim"))
async def claim(bot, m: Message):
    key = m.text[len("/claim ") :]
    status = LicenseKey().get_status(key)
    user_id = m.from_user.id
    if status == False:
        return await m.reply("Used key..")
    elif status == None:
        return await m.reply("Invalid key..")
    else:
        expire = LicenseKey().get_expire(key)
        dateinsert = date.today()
        expiration = datetime.strptime(expire, '%Y-%m-%d').date()

        User(user_id=user_id, date_activated=dateinsert, date_expiration=expiration, expired_status=False, amount=0, activation_key=key).insert_user()
        LicenseKey().update_status(key, False)
        UserDatabase().add_user(user_id)
        await m.reply(f"Your license key has been activated, it'll expire on {expire}")


@Client.on_message(filters.regex("Claim subscription"))
async def claim_re(bot, m: Message):
    x = await m.reply("Accessing db..", reply_markup=ReplyKeyboardRemove())
    await asyncio.sleep(2)
    await x.delete()
    key1 = await m.chat.ask("Send me your key: ")
    key = key1.text
    status = LicenseKey().get_status(key)
    user_id = m.from_user.id
    if status == False:
        return await m.reply("Used key..")
    elif status == None:
        return await m.reply("Invalid key..")
    else:
        expire = LicenseKey().get_expire(key)
        dateinsert = date.today()
        expiration = datetime.strptime(expire, '%Y-%m-%d').date()

        User(user_id=user_id, date_activated=dateinsert, date_expiration=expiration, expired_status=False, amount=0, activation_key=key).insert_user()
        LicenseKey().update_status(key, False)
        UserDatabase().add_user(user_id)
        await m.reply(f"Your license key has been activated, it'll expire on {expire}")