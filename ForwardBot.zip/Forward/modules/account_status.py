from pyrogram import Client, filters
from pyrogram.types import Message

from ..utils.verify_user import is_premium
from .database.main_db import User


@Client.on_message(filters.regex("Account status"))
@is_premium
async def replymsg(bot, m: Message):
    user_id = m.from_user.id
    activation = User(user_id).retrieve_user()
    statustext = f"Your status:\n\n> User id: {activation[0]}\n> Activation date: {activation[1]}\n>  Will expire on: {activation[2]}"
    await m.reply(statustext)