from pyrogram import Client, filters
from pyrogram.types import Message, KeyboardButton, ReplyKeyboardMarkup

from .. import SUPPORT_CHANNEL, SUPPORT_CHAT, SUDO, BOT_NAME
from ..utils.verify_user import is_premium
from ..utils.Emojis import Emojis
from ..strings import START_MSG




@Client.on_message(filters.regex("Normal access"))
async def normal_access(bot, m):
    if m.from_user.id not in SUDO:
        return
    text = f"Welcome {m.from_user.mention}"
    btn = ReplyKeyboardMarkup(
        [
            [
                KeyboardButton(f"{Emojis.covering_eyes} Account status {Emojis.covering_eyes}")
            ],
            [
                KeyboardButton(f"{Emojis.writing} Set forward message {Emojis.writing}"),
                KeyboardButton(f"{Emojis.magic} Start auto forward {Emojis.magic}"),
                KeyboardButton(f"{Emojis.msg1} Current forward message {Emojis.msg2}")
            ],
            [
                KeyboardButton(f"{Emojis.clock} Set Forward interval {Emojis.clock}"), 
                KeyboardButton(f"{Emojis.hmm} Current Interval {Emojis.hmm}")
                
            ],
            [
                KeyboardButton(f"{Emojis.plus} Add account {Emojis.plus}")
            ],
            [
                KeyboardButton(SUPPORT_CHAT),
                KeyboardButton(SUPPORT_CHANNEL)
            ]
        ], resize_keyboard=True, placeholder=f"Welcome to {BOT_NAME} bot..", 
    )
    await m.reply(text, reply_markup=btn)


@Client.on_message(filters.command("start"))
@is_premium
async def start(bot: Client, m: Message):
    if m.from_user.id in SUDO:
        text = "Hey boss!"
        btn = ReplyKeyboardMarkup(
            [
                [
                    KeyboardButton(f"{Emojis.star2} Owner panel {Emojis.star2}"),
                    KeyboardButton(f"{Emojis.four_leaf_clover} Normal access {Emojis.four_leaf_clover}")
                ],
            ], resize_keyboard=True, placeholder=f"Welcome Boss..", 
        )
    else:
        text = START_MSG
        btn = ReplyKeyboardMarkup(
            [
                [
                    KeyboardButton(f"{Emojis.covering_eyes} Account status {Emojis.covering_eyes}")
                ],
                [
                    KeyboardButton(f"{Emojis.writing} Set forward message {Emojis.writing}"),
                    KeyboardButton(f"{Emojis.magic} Start auto forward {Emojis.magic}"),
                    KeyboardButton(f"{Emojis.msg1} Current forward message {Emojis.msg2}")
                ],
                [
                    KeyboardButton(f"{Emojis.clock} Set Forward interval {Emojis.clock}"), 
                    KeyboardButton(f"{Emojis.hmm} Current Interval {Emojis.hmm}")
                    
                ],
                [
                    KeyboardButton(f"{Emojis.plus} Add account {Emojis.plus}")
                ],
                # [
                #     KeyboardButton(SUPPORT_CHAT),
                #     KeyboardButton(SUPPORT_CHANNEL)
                # ]
            ], resize_keyboard=True, placeholder=f"Welcome to {BOT_NAME} bot..", 
        )
    await m.reply(text, reply_markup=btn)
