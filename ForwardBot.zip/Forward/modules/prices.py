from pyrogram import Client, filters
from pyrogram.types import Message

from ..strings import PRICE_LIST



@Client.on_message(filters.regex("Buy subscription"))
async def replymsg(bot, m):
    prices = PRICE_LIST
    await m.reply(prices)