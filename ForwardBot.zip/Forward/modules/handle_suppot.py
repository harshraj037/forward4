from pyrogram import Client, filters
from pyrogram.types import Message

from ..utils.Emojis import Emojis
from .. import SUPPORT_CHANNEL, SUPPORT_CHAT





@Client.on_message(filters.regex("Chatroom"))
async def chatroom(bot, m: Message):
    await m.reply(f"Our chat room: {Emojis.four_leaf_clover} {SUPPORT_CHAT} {Emojis.four_leaf_clover}")

@Client.on_message(filters.regex("Updates"))
async def updateschannel(bot, m: Message):
    await m.reply(f"Updates channel: {Emojis.four_leaf_clover} {SUPPORT_CHANNEL} {Emojis.four_leaf_clover}")