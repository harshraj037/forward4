from pyrogram import Client, filters
from pyrogram.types import KeyboardButton, ReplyKeyboardMarkup

from .. import SUDO
from .database.main_db import UserDatabase, User


def sudo_only(f):
    async def wrapper(bot, m):
        if m.from_user.id not in SUDO:
            return
        return await f(bot, m)
    return wrapper


@Client.on_message(filters.regex("Owner panel"))
@sudo_only
async def owner_panel(bot: Client, m):
    btns = ReplyKeyboardMarkup(
        [
            [
                KeyboardButton("All users using bot ❓")
            ],
            [
                KeyboardButton("Update expiration date"),
                KeyboardButton("Update date activated")
            ],
            [
                KeyboardButton("Delete user ❗")
            ]
        ], resize_keyboard=1
    )
    await m.reply("What would you like to do?", reply_markup=btns)


@Client.on_message(filters.regex("All users using bot"))
@sudo_only
async def All_users(bot: Client, m):
    allusers = "List of all users:\n\n"
    users = UserDatabase().get_all_users()
    count = 1
    print(users)
    for i in users:
        allusers+=f"{count}: `{i[0]}`\n"
        count+=1
    await m.reply(allusers)


@Client.on_message(filters.regex("Update expiration date"))
@sudo_only
async def update_expire(bot: Client, m):
    u = await m.chat.ask("Send me user id: ")
    d = await m.chat.ask("Send me new date: ")
    msgtxt = d.text
    if len(msgtxt.split("-")[0])!=4:
        return await m.reply("Invalid date format")
    user_id = int(u.text)
    User(user_id).update_date_expiration(d.text)
    await m.reply(f"Updated expiration for user: {u.text} to {d.text}")


@Client.on_message(filters.regex("Delete user"))
@sudo_only
async def delete_user(bot: Client, m):
    u = await m.chat.ask("Send me user id: ! proceed with caution !")
    sure = await m.chat.ask("You 100% sure, `yes I am` `No!`")
    if sure.text == "yes I am":
        user_id = int(u.text)
        User(user_id).delete_user()
        UserDatabase().delete_user(user_id)
        await m.reply(f"Deleted user, moye moye.")
    else:
        await m.reply("Cancelled process.")
    


@Client.on_message(filters.regex("Update date activated"))
@sudo_only
async def update_activation(bot: Client, m):
    u = await m.chat.ask("Send me user id: ")
    d = await m.chat.ask("Send me new date: ")
    msgtxt = d.text
    if len(msgtxt.split("-")[0])!=4:
        return await m.reply("Invalid date format")
    user_id = int(u.text)
    User(user_id).update_date_activated(d.text)
    await m.reply(f"Updated activation date for user: {u.text} to {d.text}")