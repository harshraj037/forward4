import random
import string

from pyrogram import Client, filters

from .. import SUDO
from .database.main_db import LicenseKey



def generate_license_key(length):
    key = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    return key

@Client.on_message(filters.command("generate_key"))
async def generate_key(client, message):
    if message.from_user.id not in SUDO:
        return
    date = message.text[len("/generate_key ") :]
    msgtxt = date.split("-")[0]
    if len(msgtxt)!=4:
        return await message.reply("Invalid date format")
    license_key = "A"+generate_license_key(15).upper()
    LicenseKey().insert_key(license_key, date)
    await message.reply_text(f"Generated license key: `{license_key}`")
